package hangman;

public class drawing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new drawingframe("Hangman Game");
	}

}
