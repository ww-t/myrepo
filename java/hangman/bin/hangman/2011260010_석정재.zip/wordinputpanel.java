package hangman;
import java.awt.*;
import javax.swing.*;

public class wordinputpanel extends JPanel {
	JTextField iptf=new JTextField(1);
	public wordinputpanel(){
		setLayout(new FlowLayout());
		JLabel lb1=new JLabel("Guess :");
		add(lb1);
		add(iptf);
	}
}
