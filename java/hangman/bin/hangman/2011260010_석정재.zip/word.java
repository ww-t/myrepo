package hangman;
import java.util.Random;

public class word {
	String[] w=new String[7];
	Random r=new Random();
	int x;
	public word(){
		w[0]="java";
		w[1]="hankyung";
		w[2]="eclipse";
		w[3]="cookie";
		w[4]="class";
		w[5]="python";
		w[6]="hangman";
	}
	
	public void choice(){
		r.setSeed(r.nextLong());
		x=Math.abs(r.nextInt()%7);
	}
	
	public int slens(){
		return w[x].length();
	}
}
