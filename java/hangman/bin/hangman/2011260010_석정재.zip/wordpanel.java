package hangman;
import java.awt.*;

import javax.swing.*;
import javax.swing.border.LineBorder;

public class wordpanel extends JPanel {
	JLabel mtx=new JLabel("",JLabel.CENTER);
	JLabel lenlb=new JLabel("");
	String[] rightword=new String[8];
	
	public wordpanel(){
		setLayout(new FlowLayout());
		JLabel lb1=new JLabel("Word :");
		for(int i=0;i<8;i++)
			rightword[i]="_";
		mtx.setBorder(new LineBorder(Color.blue));
		mtx.setPreferredSize(new Dimension(100,30));
		add(lb1);
		add(mtx);
		add(lenlb);
	}
	
	public void rightwordupdate(String cstr,String istr){
		String rw=new String("");
		char[] cstrar=cstr.toCharArray();
		for(int i=0;i<cstr.length();i++){
			if(cstrar[i]==istr.charAt(0))
				rightword[i]=istr;
		}
		for(int i=0;i<cstr.length();i++){
			rw+=rightword[i];
		}
		mtx.setText(rw);
	}
	
	public void wordlenupdate(int len){
		lenlb.setText("Length : "+len+" characters");
	}
	
	public void reset(int len,String cstr){
		int i;
		for(i=0;i<8;i++)
			rightword[i]="_";
		rightwordupdate(cstr," ");
		wordlenupdate(len);
	}
}
