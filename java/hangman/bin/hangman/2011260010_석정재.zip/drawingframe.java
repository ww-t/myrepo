package hangman;
import java.awt.*;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Dialog.ModalityType;
import java.awt.event.*;

import javax.swing.*;

public class drawingframe extends JFrame implements KeyListener {
	
	hangmandraw hmd=new hangmandraw();
	JPanel tp=new JPanel();
	wordpanel wp=new wordpanel();
	wordinputpanel wip=new wordinputpanel();
	wrongwordpanel wwp=new wrongwordpanel();
	word w=new word();
	JFrame infof=new JFrame();
	JDialog info=new JDialog(infof,"Hangman Info",false);
	JLabel lb1=new JLabel("",JLabel.CENTER);
	JLabel lb2=new JLabel("",JLabel.CENTER);
	
	public drawingframe(String str){
		super(str);
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		w.choice();
		wp.rightwordupdate(w.w[w.x]," ");
		wp.wordlenupdate(w.slens());
		wwp.wrongwordupdate();
		tp.setLayout(new GridLayout(3,1));
		tp.setPreferredSize(new Dimension(400,150));
		tp.add(wp);
		tp.add(wip);
		tp.add(wwp);
		wip.iptf.addKeyListener(this);
		add(hmd);
		add(tp);
		setBounds(0,0,1000,560);
		setVisible(true);
	}

	@Override
	public void keyPressed(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

	@Override
	public void keyTyped(KeyEvent e) {
		if(e.getKeyChar()==e.VK_ENTER){
			String inputstr=wip.iptf.getText();
			int index=w.w[w.x].indexOf(inputstr);
			if(inputstr.length()==1&&inputstr.charAt(0)>='a'&&inputstr.charAt(0)<='z'&&wwp.mwlb.getText().indexOf(inputstr)==-1){
				if(index>=0){
					wp.rightwordupdate(w.w[w.x],inputstr);
					if(wp.mtx.getText().compareTo(w.w[w.x])==0){
						infodialog("you win");
						w.choice();
						hmd.reset();
						wp.reset(w.slens(),w.w[w.x]);
						wwp.reset();
					}
				}
				else{
					wwp.wrongwordinput(inputstr);
					wwp.wrongwordupdate();
					if(hmd.increase()){
						infodialog("you lose");
						w.choice();
						hmd.reset();
						wp.reset(w.slens(),w.w[w.x]);
						wwp.reset();
					}
				}
			}
			wip.iptf.setText("");
		}
	}

	public void infodialog(String str){
		info.setLayout(new GridLayout(2,1));
		info.add(lb1);
		info.add(lb2);
		lb1.setText(str);
		lb2.setText("correct answer : "+w.w[w.x]);
		infof.setDefaultCloseOperation(EXIT_ON_CLOSE);
		info.setBounds(400, 180, 200, 200);
		info.setVisible(true);
	}
}
