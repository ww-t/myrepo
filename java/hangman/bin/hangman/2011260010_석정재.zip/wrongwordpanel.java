package hangman;
import java.awt.*;

import javax.swing.*;

public class wrongwordpanel extends JPanel {
	JLabel mwlb=new JLabel("");
	String[] wrongword=new String[8];
	int id=7;
	
	public wrongwordpanel(){
		setLayout(new FlowLayout());
		JLabel lb1=new JLabel("Misses :");
		for(int i=0;i<8;i++)
			wrongword[i]="";
		mwlb.setPreferredSize(new Dimension(70,30));
		add(lb1);
		add(mwlb);
	}
	
	public void wrongwordupdate(){
		int i,j;
		String ww=new String("");
		for(i=0;i<7;i++){
			for(j=0;j<8;j++){
				if(wrongword[i].compareTo(wrongword[i+1])>0){
					String temp=wrongword[i];
					wrongword[i]=wrongword[i+1];
					wrongword[i+1]=temp;
				}
			}
		}
		
		for(i=0;i<8;i++){
			if(wrongword[i].isEmpty())
				continue;
			else
				ww+=wrongword[i]+" ";
		}
		
		mwlb.setText(ww);
	}
	
	public void wrongwordinput(String input){
		wrongword[id]=input;
		id--;
	}
	
	public void reset(){
		int i;
		for(i=0;i<8;i++)
			wrongword[i]="";
		id=7;
		mwlb.setText("");
	}
}
